import { useState } from "react";

import { calcularResumo } from "../services/calculos";
import Resumo from "../components/Resumo";
import Section from "../components/Section";
import Header from "../components/Header";
import TabelaCartoes from "../components/TabelaCartoes";
import { outrosValores, saidas } from "../data/campos";
import Toolbar from "../components/Toolbar";

function Caixa() {
  const [valores, setValores] = useState({
    visaDebito: "",
    visaCredito: "",

    masterDebito: "",
    masterCredito: "",

    eloDebito: "",
    eloCredito: "",

    amex: "",

    pixSicoob: "",
    pixMaq: "",
    transferencias: "",

    sangrias: "",
    despesas: "",
    vales: "",

    credito: "",

    produtos: "",
    combustivel: "",
    creditos: "",

    contado: "",
  });

  function alterarCampo(nome, valor) {
    setValores({
      ...valores,
      [nome]: valor,
    });
  }

  const resumo = calcularResumo(valores);

  return (
    <div className="container">
      <Header />

    <Toolbar />

    <div className="grid">
        <TabelaCartoes
          valores={valores}
          alterarCampo={alterarCampo}
          resumo={resumo}
        />

        <Section
          titulo="Movimentação"
          campos={outrosValores}
          valores={valores}
          alterarCampo={alterarCampo}
        />
      </div>
      <Section
        titulo="Saídas"
        campos={saidas}
        valores={valores}
        alterarCampo={alterarCampo}
      />
      <Resumo resumo={resumo} valores={valores} alterarCampo={alterarCampo} />
    </div>
  );
}

export default Caixa;
