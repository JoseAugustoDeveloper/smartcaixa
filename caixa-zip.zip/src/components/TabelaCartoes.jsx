import Card from "./Card";

function TabelaCartoes({ valores, alterarCampo, resumo }) {
  return (
    <Card titulo="💳 Cartões">

      <table className="tabela-cartoes">

        <thead>
          <tr>
            <th>Bandeira</th>
            <th>Débito</th>
            <th>Crédito</th>
          </tr>
        </thead>

        <tbody>

          <tr>
            <td>Visa</td>

            <td>
              <input
                type="number"
                value={valores.visaDebito}
                onChange={(e) =>
                  alterarCampo("visaDebito", e.target.value)
                }
              />
            </td>

            <td>
              <input
                type="number"
                value={valores.visaCredito}
                onChange={(e) =>
                  alterarCampo("visaCredito", e.target.value)
                }
              />
            </td>
          </tr>

          <tr>
            <td>Master</td>

            <td>
              <input
                type="number"
                value={valores.masterDebito}
                onChange={(e) =>
                  alterarCampo("masterDebito", e.target.value)
                }
              />
            </td>

            <td>
              <input
                type="number"
                value={valores.masterCredito}
                onChange={(e) =>
                  alterarCampo("masterCredito", e.target.value)
                }
              />
            </td>
          </tr>

          <tr>
            <td>Elo</td>

            <td>
              <input
                type="number"
                value={valores.eloDebito}
                onChange={(e) =>
                  alterarCampo("eloDebito", e.target.value)
                }
              />
            </td>

            <td>
              <input
                type="number"
                value={valores.eloCredito}
                onChange={(e) =>
                  alterarCampo("eloCredito", e.target.value)
                }
              />
            </td>
          </tr>

          <tr>
            <td>Amex</td>

            <td>-</td>

            <td>
              <input
                type="number"
                value={valores.amex}
                onChange={(e) =>
                  alterarCampo("amex", e.target.value)
                }
              />
            </td>
          </tr>

        </tbody>

      </table>

      <div className="totais-cartoes">

        <div>
          <strong>Total Débito</strong>
          <span>
            R$ {resumo.totalDebito.toFixed(2)}
          </span>
        </div>

        <div>
          <strong>Total Crédito</strong>
          <span>
            R$ {resumo.totalCredito.toFixed(2)}
          </span>
        </div>

      </div>

    </Card>
  );
}

export default TabelaCartoes;