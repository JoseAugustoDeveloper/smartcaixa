function Toolbar() {
  return (
    <div className="toolbar">

      <button className="btn salvar">
        💾 Salvar
      </button>

      <button className="btn novo">
        🆕 Novo
      </button>

      <button className="btn pdf">
        📄 PDF A4
      </button>

      <button className="btn cupom">
        🧾 Cupom
      </button>

      <button className="btn historico">
        📂 Histórico
      </button>

    </div>
  );
}

export default Toolbar;