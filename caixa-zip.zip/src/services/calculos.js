function valor(numero) {
    return Number(numero || 0) / 100;
}

export function calcularResumo(valores) {

    const totalDebito =
        valor(valores.visaDebito) +
        valor(valores.masterDebito) +
        valor(valores.eloDebito);

    const totalCredito =
        valor(valores.visaCredito || 0) +
        valor(valores.masterCredito || 0) +
        valor(valores.eloCredito || 0) +
        valor(valores.amex || 0);

    const entradas =
        totalDebito +
        totalCredito +
        valor(valores.pixSicoob || 0) +
        valor(valores.pixMaq || 0) +
        valor(valores.transferencias || 0) +
        valor(valores.credito || 0) +
        valor(valores.vales || 0) +
        valor(valores.despesas || 0);

    const sangrias = valor(valores.sangrias || 0);

    const saidas =
        valor(valores.produtos || 0) +
        valor(valores.combustivel || 0) +
        valor(valores.creditos || 0);

    const diferenca = entradas - saidas;

    const totalMovimentacao = entradas + saidas;

    let resultado = "Caixa Fechado";

    if (diferenca > 0) {
        resultado = "Sobra";
    } else if (diferenca < 0) {
        resultado = "Falta";
    }

    return {
        totalDebito,
        totalCredito,
        entradas,
        sangrias,
        saidas,
        diferenca,
        totalMovimentacao,
        resultado
    };
}